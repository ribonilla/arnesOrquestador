# 🏛️ 01. Dirección y Estrategia

Esta macro-carpeta responde a la pregunta de negocio: **¿Por qué y bajo qué reglas hacemos este proyecto?**

Aquí se definen las bases, restricciones, acuerdos vinculantes y los aprendizajes que blindan la ejecución.

## 🔎 ¿Qué hay aquí y cómo encuentro lo último?

Para ver lo más reciente, abre el índice correspondiente (ordenado por fecha, de más nuevo a más antiguo):

* ⚖️ Decisiones y acuerdos: [[.harness/Plantillas/TPL_IDX_Decisiones.base|Índice de decisiones]]
* 🧠 Aprendizajes: [[.harness/Plantillas/TPL_IDX_Aprendizajes.base|Índice de aprendizajes]]

También puedes ver la última decisión en la sección **Dónde quedé** de `00_Centro_de_Mando.md`.

---

## 📂 Subcarpetas y Contenidos

### 🎯 1. `Alcance_y_Objetivos/`
* **Propósito:** El mandato y el caso de negocio innegociable.
* **Documentos Clave:**
  - `Business_Case_y_Objetivo.md`: Quién es el Sponsor, cuál es la Audiencia, qué decisiones debe detonar el trabajo y cuáles son los límites de tiempo y presupuesto.

### ⚖️ 2. `Decisiones_y_Acuerdos/`
* **Propósito:** Registro auditable y trazabilidad histórica.
* **Documentos Clave:**
  - `Matriz_de_Cambios_y_Acuerdos.md`: Cada ajuste a números, cambios de criterio o acuerdos de reuniones se asienta aquí con fecha y hora (`YYYY-MM-DD HH:MM`), autor y justificación.
  - Informes de auditoría de bóveda generados para comités o el sponsor.

### 🧠 3. `Aprendizajes_y_Conocimiento/`
* **Propósito:** El banco Zettelkasten reutilizable de lecciones aprendidas y mejores prácticas.
* **Documentos Clave:**
  - Notas atómicas de arquitectura, metodologías y lecciones aprendidas en proyectos reales.
  - `Prompts/`: Biblioteca de patrones de interacción. Muestra cómo formula el usuario las solicitudes normalmente y cómo sugerirle versiones de alto impacto sin exigirle conocer la fontanería interna de la bóveda.
  - Principio activo: Toda pregunta o duda del usuario (ej. descuadres de fórmulas en Excel) se investiga y se capitaliza como nota en esta carpeta.
